﻿using Avalonia.Controls;

namespace SecondTry.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
