﻿using CommunityToolkit.Mvvm.ComponentModel;
using ReactiveUI;

namespace SecondTry.ViewModels;

public class ViewModelBase : ReactiveObject
{
}
